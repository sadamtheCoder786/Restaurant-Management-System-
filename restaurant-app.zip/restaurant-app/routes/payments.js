const express = require('express');
const router = express.Router();
const db = require('./db'); // adjust this path as needed

// Get all payments
router.get('/', (req, res) => {
  db.query('SELECT payment_id, order_id, amount, payment_method, payment_date, status FROM payments', (err, result) => {
    if (err) {
      console.error('Error fetching payments:', err);
      return res.status(500).json({ error: 'Failed to fetch payments' });
    }
    res.json(result.rows);
  });
});

module.exports = router;
