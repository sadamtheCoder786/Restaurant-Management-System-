const express = require('express');
const router = express.Router();
const db = require('./db'); // PostgreSQL pool

// 🔍 GET /api/orders - Get all orders (even with missing customer or reservation)
router.get('/', async (req, res) => {
  try {
    const result = await db.query(`
      SELECT 
        o.order_id,
        o.customer_id,
        o.reservation_id,
        o.order_date,
        o.status,
        c.name AS customer_name,
        c.phone AS customer_phone,
        r.reservation_time
      FROM orders o
      LEFT JOIN customers c ON o.customer_id = c.customer_id
      LEFT JOIN reservations r ON o.reservation_id = r.reservation_id
      ORDER BY o.order_date DESC, o.order_id DESC;
    `);
    console.log('✅ Orders fetched:', result.rowCount);
    res.json(result.rows);
  } catch (err) {
    console.error('❌ Error loading orders:', err);
    res.status(500).json({ error: 'Server error fetching orders' });
  }
});

// ➕ POST /api/orders - Add new order
router.post('/', async (req, res) => {
  const { customer_id, reservation_id, order_date, status } = req.body;

  if (!customer_id || !reservation_id || !order_date || !status) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    await db.query(
      `INSERT INTO orders (customer_id, reservation_id, order_date, status)
       VALUES ($1, $2, $3, $4)`,
      [customer_id, reservation_id, order_date, status]
    );
    res.status(200).json({ message: 'Order placed successfully' });
  } catch (err) {
    console.error('❌ Error placing order:', err.message);
    res.status(500).json({ message: 'Failed to place order' });
  }
});

// ✏️ PUT /api/orders/:order_id - Update an order
router.put('/:order_id', async (req, res) => {
  const { order_id } = req.params;
  const { customer_id, reservation_id, order_date, status } = req.body;

  if (!customer_id || !reservation_id || !order_date || !status) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const result = await db.query(
      `UPDATE orders
       SET customer_id = $1, reservation_id = $2, order_date = $3, status = $4
       WHERE order_id = $5`,
      [customer_id, reservation_id, order_date, status, order_id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: 'Order not found' });
    }

    res.status(200).json({ message: 'Order updated successfully' });
  } catch (err) {
    console.error('❌ Error updating order:', err.message);
    res.status(500).json({ message: 'Failed to update order' });
  }
});

// 🗑️ DELETE /api/orders/:order_id - Delete an order
router.delete('/:order_id', async (req, res) => {
  const { order_id } = req.params;

  try {
    const result = await db.query(
      `DELETE FROM orders WHERE order_id = $1`,
      [order_id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: 'Order not found' });
    }

    res.status(200).json({ message: 'Order deleted successfully' });
  } catch (err) {
    console.error('❌ Error deleting order:', err.message);
    res.status(500).json({ message: 'Failed to delete order' });
  }
});

module.exports = router;
