const express = require('express');
const router = express.Router();
const db = require('./db');

// Get all reservations
router.get('/', (req, res) => {
  db.query('SELECT * FROM reservations', (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results.rows); // 👈 Important for PostgreSQL
  });
});

// Add a new reservation
router.post('/', (req, res) => {
  const { customer_id, table_id, reservation_time, status } = req.body;
  db.query(
    'INSERT INTO reservations (customer_id, table_id, reservation_time, status) VALUES ($1, $2, $3, $4) RETURNING *',
    [customer_id, table_id, reservation_time, status],
    (err, result) => {
      if (err) return res.status(500).json({ error: 'Insert error' });
      res.status(201).json(result.rows[0]);
    }
  );
});

module.exports = router;
