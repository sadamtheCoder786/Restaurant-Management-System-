const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const db = require('./db'); // Adjust if needed

// Register route
router.post('/register', async (req, res) => {
  const { username, password, role } = req.body;
  try {
    const hashed = await bcrypt.hash(password, 10);
    await db.query(
      'INSERT INTO users (username, password_hash, role) VALUES ($1, $2, $3)',
      [username, hashed, role]
    );
    res.redirect('/login');
  } catch (err) {
    console.error('Registration Error:', err);
    res.status(500).send('Registration failed.');
  }
});

// Login route
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const result = await db.query('SELECT * FROM users WHERE username = $1', [username]);

  if (result.rows.length && await bcrypt.compare(password, result.rows[0].password_hash)) {
    req.session.user = {
      id: result.rows[0].user_id,
      username,
      role: result.rows[0].role
    };
    res.redirect('/dashboard');
  } else {
    res.send('Invalid login');
  }
});

// Logout route
router.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Logout error:', err);
      return res.status(500).send('Logout failed');
    }
    res.redirect('/login');
  });
});

// Middleware
function isAuthenticated(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  } else {
    res.redirect('/login');
  }
}

module.exports = { router, isAuthenticated };
