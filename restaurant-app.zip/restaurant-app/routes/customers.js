const express = require('express');
const router = express.Router();
const db = require('./db'); // pg Pool

// GET all customers
router.get('/', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM customers ORDER BY customer_id ASC');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching customers:', err);
    res.status(500).json({ error: 'Server error loading customers' });
  }
});

// POST - Add new customer
router.post('/', async (req, res) => {
  const { name, phone, email } = req.body;
  try {
    const result = await db.query(
      'INSERT INTO customers (name, phone, email) VALUES ($1, $2, $3) RETURNING customer_id',
      [name, phone, email]
    );
    res.status(201).json({ message: 'Customer added', id: result.rows[0].customer_id });
  } catch (err) {
    console.error('Error adding customer:', err);
    res.status(500).json({ error: 'Failed to add customer' });
  }
});

// PUT - Update customer
router.put('/:id', async (req, res) => {
  const { name, phone, email } = req.body;
  const id = req.params.id;
  try {
    await db.query(
      'UPDATE customers SET name = $1, phone = $2, email = $3 WHERE customer_id = $4',
      [name, phone, email, id]
    );
    res.json({ message: 'Customer updated' });
  } catch (err) {
    console.error('Error updating customer:', err);
    res.status(500).json({ error: 'Failed to update customer' });
  }
});

// DELETE - Delete customer
router.delete('/:id', async (req, res) => {
  const id = req.params.id;
  try {
    await db.query('DELETE FROM customers WHERE customer_id = $1', [id]);
    res.json({ message: 'Customer deleted' });
  } catch (err) {
    console.error('Error deleting customer:', err);
    res.status(500).json({ error: 'Failed to delete customer' });
  }
});

module.exports = router;
