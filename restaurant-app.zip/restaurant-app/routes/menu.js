// routes/menu.js
const express = require('express');
const router = express.Router();
const db = require('./db'); // or '../db' based on your file structure


router.post('/', async (req, res) => {
  const { name, category, price } = req.body;
  try {
    const result = await db.query(
      'INSERT INTO menu_items (name, category, price) VALUES ($1, $2, $3) RETURNING *',
      [name, category, price]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('❌ Failed to add menu item:', err);
    res.status(500).json({ error: 'Server error adding item' });
  }
});


router.get('/', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM menu_items ORDER BY item_id ASC');
    res.json(result.rows); // ✅ must return an array
  } catch (err) {
    console.error('❌ Error loading menu:', err.message);
    res.status(500).json({ error: 'Server error fetching menu items' });
  }
});

router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM menu_items WHERE item_id = $1', [id]);
    res.json({ message: 'Item deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete menu item' });
  }
});

// UPDATE a menu item
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { name, description, price } = req.body;
  try {
    await db.query(
      `UPDATE menu_items SET name = $1, description = $2, price = $3 WHERE item_id = $4`,
      [name, description, price, id]
    );
    res.json({ message: 'Item updated successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update menu item' });
  }
});
module.exports = router;
