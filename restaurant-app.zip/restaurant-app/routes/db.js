const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL, // stored in your .env
  ssl: {
    rejectUnauthorized: false, // required for Neon
  },
});

pool.connect((err, client, release) => {
  if (err) {
    return console.error(' Error connecting to PostgreSQL:', err.stack);
  }
  console.log('✅ PostgreSQL connected');
  release(); 
});

module.exports = pool;
