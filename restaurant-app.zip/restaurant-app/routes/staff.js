// routes/staff.js
const express = require('express');
const router = express.Router();
const pool = require('./db'); // PostgreSQL pool connection

// ✅ GET all staff
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT staff_id AS id, name, phone, email, role FROM staff'
    );
    res.json(result.rows);
  } catch (err) {
    console.error('❌ Error fetching staff:', err);
    res.status(500).send('Error fetching staff');
  }
});

// ✅ POST new staff
router.post('/', async (req, res) => {
  const { name, phone, email, password, role } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO staff (name, phone, email, password, role) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [name, phone, email, password, role]
    );
    res.json({ message: '✅ Staff added', staff: result.rows[0] });
  } catch (err) {
    console.error('❌ Error inserting staff:', err);
    res.status(500).send('Error adding staff');
  }
});

// ✅ PUT update staff
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { name, phone, email, password, role } = req.body;
  try {
    const result = await pool.query(
      'UPDATE staff SET name = $1, phone = $2, email = $3, password = $4, role = $5 WHERE staff_id = $6 RETURNING *',
      [name, phone, email, password, role, id]
    );
    res.json({ message: '✅ Staff updated', staff: result.rows[0] });
  } catch (err) {
    console.error('❌ Error updating staff:', err);
    res.status(500).send('Error updating staff');
  }
});


router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM staff WHERE staff_id = $1', [id]);
    res.json({ message: '✅ Staff deleted' });
  } catch (err) {
    console.error('❌ Error deleting staff:', err);
    res.status(500).send('Error deleting staff');
  }
});


module.exports = router;
