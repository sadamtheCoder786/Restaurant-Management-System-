require('dotenv').config();
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');
const db = require('./routes/db');

const app = express();
const PORT = process.env.PORT || 3000;

// ✅ Session middleware (must come before route usage)
app.use(session({
  secret: 'yourSecretKey',
  resave: false,
  saveUninitialized: false,
}));

// ✅ Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ✅ Route modules
const { router: authRoutes, isAuthenticated } = require('./routes/auth');
const ordersRoutes = require('./routes/orders');
const menuRoutes = require('./routes/menu');
const staffRoutes = require('./routes/staff');
const customersRoutes = require('./routes/customers');
const paymentsRoutes = require('./routes/payments');
const reservationRoutes = require('./routes/reservations');


// ✅ Auth routes
app.use(authRoutes);

app.get('/', (req, res) => {
  if (req.session && req.session.user) {
    res.redirect('/dashboard');
  } else {
    res.redirect('/login');
  }
});


// Public pages
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'webpages', 'login.html'));
});

app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'webpages', 'register.html'));
});

// ✅ Protected dashboard
app.get('/dashboard', isAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'webpages', 'orders', 'orders.html'));
});

// ✅ Other protected views
app.get('/staff', isAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'webpages', 'staff', 'staff.html'));
});

// ✅ Home redirects to login


// ✅ API routes
app.use('/api/orders', ordersRoutes);
app.use('/api/menu', menuRoutes);
app.use('/api/customers', customersRoutes);
app.use('/api/staff', staffRoutes);
app.use('/api/payments', paymentsRoutes);
app.use('/api/reservations', reservationRoutes);

// ✅ Submit order handler
app.post('/api/submit-order', async (req, res) => {
  const { customer_id, table_number, item_id, quantity, payment_id } = req.body;

  try {
    const priceResult = await db.query('SELECT price FROM menu_items WHERE item_id = $1', [item_id]);
    if (priceResult.rows.length === 0) return res.status(404).send('Item not found');

    const unitPrice = priceResult.rows[0].price;
    const total_price = unitPrice * quantity;

    await db.query(
      `INSERT INTO orders (customer_id, table_number, item_id, quantity, total_price, payment_id)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [customer_id, table_number, item_id, quantity, total_price, payment_id]
    );

    res.send('<h2>✅ Order placed successfully!</h2><a href="/">⬅ Back to Orders</a>');
  } catch (err) {
    console.error('Error placing order:', err);
    res.status(500).send('Server error during order placement');
  }
});

// ✅ Start server
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);

  // ✅ Safe dynamic import of open (AFTER PORT is defined)
  import('open').then(open => open.default(`http://localhost:${PORT}/`));
});
